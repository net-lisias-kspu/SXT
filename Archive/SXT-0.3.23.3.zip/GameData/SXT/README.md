# SXTContinued
Lack's Stock eXTension 

http://forum.kerbalspaceprogram.com/index.php?/topic/151129-12-sxt-continued-beta/

This is a revival of the SXT - Stock eXTension mod, originally published by @Lack

Updated for 1.2.  The truck had some parts redone and works well, it includes the Bounce dll from the WorldCup mod (for the airbags), and RetractableLiftingSurface, which I wrote to support the folding wing.

Given the size of this mod, I'm sure there will be some issues.  Please let me know about them so that I can get them fixed.

A great shout out to @Deimos Rast for doing a lot of the early legwork

SXT - The Full Pack - Downloads

Github link: https://github.com/linuxgurugamer/SXTContinued

SXT-0.3.0

http://spacedock.info/mod/1030/SXTContinued
https://github.com/linuxgurugamer/SXTContinued/releases
