Changelog:
v21
* Added missing assets to OldAssets (Mk1 inline old textures; circular intake old textures).
* Converted to DDS.
* Removed FINAL from some MM patches to aid in compatibility.
* Don't change ion engine if Ven's Stock Revamp is installed.
* Added license for bundled Firespitter plugin.

v20
Final version for .90